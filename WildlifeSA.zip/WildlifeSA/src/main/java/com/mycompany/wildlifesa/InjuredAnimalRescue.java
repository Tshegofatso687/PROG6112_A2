/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wildlifesa;

/**
 *
 * @author tshegofatso thamane (ST10515734)
 */




public class InjuredAnimalRescue extends RescueCase {

    private String injuryDescription;
    private double veterinaryTreatmentCost;
    private boolean surgeryRequired;

    public InjuredAnimalRescue(
            String rescueCaseId,
            String animalName,
            String species,
            String rescueLocation,
            String assignedRanger,
            int numberOfRescueDays,
            double dailyCareCost,
            String injuryDescription,
            double veterinaryTreatmentCost,
            boolean surgeryRequired) {

        super(
                rescueCaseId,
                animalName,
                species,
                rescueLocation,
                assignedRanger,
                numberOfRescueDays,
                dailyCareCost
        );

        this.injuryDescription = injuryDescription;
        this.veterinaryTreatmentCost = veterinaryTreatmentCost;
        this.surgeryRequired = surgeryRequired;
    }

    public String getInjuryDescription() {
        return injuryDescription;
    }

    public double getVeterinaryTreatmentCost() {
        return veterinaryTreatmentCost;
    }

    public boolean isSurgeryRequired() {
        return surgeryRequired;
    }

    @Override
    public double calculateTotalRescueCost() {

        double total = calculateBasicRescueCost();

        total += veterinaryTreatmentCost;

        if (surgeryRequired) {
            total += 5000;
        }

        return total;
    }

    @Override
    public String determineRescuePriority() {

        if (surgeryRequired) {
            return "High";
        }

        return "Medium";
    }

    @Override
    public String getRescueType() {
        return "Injured Animal Rescue";
    }

    @Override
    public String displaySpecificInformation() {

        String information = "";

        information += "Injury Description: "
                + injuryDescription + "\n";

        information += String.format(
                "Veterinary Treatment Cost: R%.2f%n",
                veterinaryTreatmentCost);

        information += "Surgery Required: "
                + (surgeryRequired ? "Yes" : "No") + "\n";

        return information;
    }
}