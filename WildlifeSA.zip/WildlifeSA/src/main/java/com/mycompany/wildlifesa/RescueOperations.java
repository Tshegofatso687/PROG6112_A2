/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wildlifesa;

/**
 *
 * @author tshegofatso thamane (ST10515734)
 */


public interface RescueOperations {

    void startRescue();

    void completeRescue();

    String generateRescueSummary();
}
