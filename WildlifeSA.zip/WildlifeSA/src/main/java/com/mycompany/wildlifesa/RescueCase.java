/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wildlifesa;

/**
 *
 * @author tshegofatso thamane (ST10515734)
 */


public abstract class RescueCase implements RescueOperations {

    private String rescueCaseId;
    private String animalName;
    private String species;
    private String rescueLocation;
    private String assignedRanger;
    private int numberOfRescueDays;
    private double dailyCareCost;
    private String currentRescueStatus;

    public RescueCase(String rescueCaseId, String animalName, String species,
                      String rescueLocation, String assignedRanger,
                      int numberOfRescueDays, double dailyCareCost) {

        this.rescueCaseId = rescueCaseId;
        this.animalName = animalName;
        this.species = species;
        this.rescueLocation = rescueLocation;
        this.assignedRanger = assignedRanger;
        this.numberOfRescueDays = numberOfRescueDays;
        this.dailyCareCost = dailyCareCost;
        this.currentRescueStatus = "Awaiting Rescue";
    }

    public String getRescueCaseId() {
        return rescueCaseId;
    }

    public String getAnimalName() {
        return animalName;
    }

    public String getSpecies() {
        return species;
    }

    public String getRescueLocation() {
        return rescueLocation;
    }

    public String getAssignedRanger() {
        return assignedRanger;
    }

    public int getNumberOfRescueDays() {
        return numberOfRescueDays;
    }

    public double getDailyCareCost() {
        return dailyCareCost;
    }

    public String getCurrentRescueStatus() {
        return currentRescueStatus;
    }

    public void setCurrentRescueStatus(String currentRescueStatus) {
        this.currentRescueStatus = currentRescueStatus;
    }

    public double calculateBasicRescueCost() {
        return numberOfRescueDays * dailyCareCost;
    }

    public abstract double calculateTotalRescueCost();

    public abstract String determineRescuePriority();

    public abstract String getRescueType();

    public abstract String displaySpecificInformation();

    @Override
    public void startRescue() {
        currentRescueStatus = "Rescue In Progress";
    }

    @Override
    public void completeRescue() {
        currentRescueStatus = "Completed";
    }

    @Override
    public String generateRescueSummary() {

        StringBuilder summary = new StringBuilder();

        summary.append("\n========== RESCUE SUMMARY ==========\n");
        summary.append("Rescue Case ID: ").append(rescueCaseId).append("\n");
        summary.append("Rescue Type: ").append(getRescueType()).append("\n");
        summary.append("Animal Name: ").append(animalName).append("\n");
        summary.append("Species: ").append(species).append("\n");
        summary.append("Rescue Location: ").append(rescueLocation).append("\n");
        summary.append("Assigned Ranger: ").append(assignedRanger).append("\n");
        summary.append("Rescue Priority: ").append(determineRescuePriority()).append("\n");
        summary.append("Current Status: ").append(currentRescueStatus).append("\n");
        summary.append(String.format("Total Rescue Cost: R%.2f%n",
                calculateTotalRescueCost()));
        summary.append("\nType-Specific Information:\n");
        summary.append(displaySpecificInformation());
        summary.append("====================================\n");

        return summary.toString();
    }
}