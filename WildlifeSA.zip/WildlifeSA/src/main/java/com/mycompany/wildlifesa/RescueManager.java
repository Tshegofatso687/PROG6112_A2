/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wildlifesa;

/**
 *
 * @author tshegofatso thamane (ST10515734)
 */


import java.util.ArrayList;

public class RescueManager {

    private ArrayList<RescueCase> rescueCases;

    public RescueManager() {
        rescueCases = new ArrayList<>();
    }

    // Add a new rescue case
    public boolean addRescueCase(RescueCase rescueCase) {

        if (rescueCase == null) {
            return false;
        }

        if (rescueCase.getRescueCaseId() == null
                || rescueCase.getRescueCaseId().trim().isEmpty()) {
            return false;
        }

        // Prevent duplicate Rescue Case IDs
        if (searchRescueCase(rescueCase.getRescueCaseId()) != null) {
            return false;
        }

        rescueCases.add(rescueCase);
        return true;
    }

    // Search for a rescue case using its ID
    public RescueCase searchRescueCase(String rescueCaseId) {

        if (rescueCaseId == null || rescueCaseId.trim().isEmpty()) {
            return null;
        }

        for (RescueCase rescueCase : rescueCases) {

            if (rescueCase.getRescueCaseId()
                    .equalsIgnoreCase(rescueCaseId.trim())) {

                return rescueCase;
            }
        }

        return null;
    }

    // Start a rescue operation
    public boolean startRescueOperation(String rescueCaseId) {

        RescueCase rescueCase = searchRescueCase(rescueCaseId);

        if (rescueCase == null) {
            return false;
        }

        rescueCase.startRescue();
        return true;
    }

    // Complete a rescue operation
    public boolean completeRescueOperation(String rescueCaseId) {

        RescueCase rescueCase = searchRescueCase(rescueCaseId);

        if (rescueCase == null) {
            return false;
        }

        rescueCase.completeRescue();
        return true;
    }

    // Generate a summary for one rescue case
    public String generateRescueSummary(String rescueCaseId) {

        RescueCase rescueCase = searchRescueCase(rescueCaseId);

        if (rescueCase == null) {
            return null;
        }

        return rescueCase.generateRescueSummary();
    }

    // Display all rescue cases
    public void displayAllRescueCases() {

        if (rescueCases.isEmpty()) {

            System.out.println("\nNo rescue cases found.");
            return;
        }

        System.out.println("\n========== ALL RESCUE CASES ==========");

        for (RescueCase rescueCase : rescueCases) {

            System.out.println("--------------------------------------");

            System.out.println("Rescue Case ID: "
                    + rescueCase.getRescueCaseId());

            System.out.println("Rescue Type: "
                    + rescueCase.getRescueType());

            System.out.println("Animal Name: "
                    + rescueCase.getAnimalName());

            System.out.println("Species: "
                    + rescueCase.getSpecies());

            System.out.println("Rescue Location: "
                    + rescueCase.getRescueLocation());

            System.out.println("Assigned Ranger: "
                    + rescueCase.getAssignedRanger());

            System.out.println("Rescue Priority: "
                    + rescueCase.determineRescuePriority());

            System.out.println("Current Status: "
                    + rescueCase.getCurrentRescueStatus());

            System.out.printf("Total Rescue Cost: R%.2f%n",
                    rescueCase.calculateTotalRescueCost());
        }

        System.out.println("======================================");
    }

    // Generate the complete rescue report required by the assignment
    public void generateRescueReport() {

        System.out.println("\n");
        System.out.println("==============================================");
        System.out.println("          WILDLIFE SA RESCUE REPORT");
        System.out.println("==============================================");

        if (rescueCases.isEmpty()) {

            System.out.println("No rescue cases currently stored.");
            System.out.println("----------------------------------------------");
            System.out.println("Total Number of Rescue Cases: 0");
            System.out.println("Total Estimated Rescue Cost: R0.00");
            System.out.println("==============================================");

            return;
        }

        double totalEstimatedCost = 0.0;

        for (RescueCase rescueCase : rescueCases) {

            System.out.println("----------------------------------------------");

            System.out.println("Rescue Case ID: "
                    + rescueCase.getRescueCaseId());

            System.out.println("Rescue Type: "
                    + rescueCase.getRescueType());

            System.out.println("Species: "
                    + rescueCase.getSpecies());

            System.out.println("Rescue Location: "
                    + rescueCase.getRescueLocation());

            System.out.println("Assigned Ranger: "
                    + rescueCase.getAssignedRanger());

            System.out.println("Rescue Priority: "
                    + rescueCase.determineRescuePriority());

            System.out.println("Current Status: "
                    + rescueCase.getCurrentRescueStatus());

            double rescueCost = rescueCase.calculateTotalRescueCost();

            System.out.printf("Total Rescue Cost: R%.2f%n",
                    rescueCost);

            totalEstimatedCost += rescueCost;
        }

        System.out.println("----------------------------------------------");

        System.out.println("Total Number of Rescue Cases: "
                + rescueCases.size());

        System.out.printf("Total Estimated Rescue Cost: R%.2f%n",
                totalEstimatedCost);

        System.out.println("==============================================");
    }

    // Get all rescue cases
    public ArrayList<RescueCase> getRescueCases() {
        return rescueCases;
    }

    // Get number of rescue cases
    public int getNumberOfRescueCases() {
        return rescueCases.size();
    }
}