/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wildlifesa;

/**
 *
 * @author tshegofatso thamane (ST10515734)
 */




public class EndangeredSpeciesRescue extends RescueCase {

    private String conservationClassification;
    private double securityCost;
    private boolean specialistTeamRequired;

    public EndangeredSpeciesRescue(
            String rescueCaseId,
            String animalName,
            String species,
            String rescueLocation,
            String assignedRanger,
            int numberOfRescueDays,
            double dailyCareCost,
            String conservationClassification,
            double securityCost,
            boolean specialistTeamRequired) {

        super(
                rescueCaseId,
                animalName,
                species,
                rescueLocation,
                assignedRanger,
                numberOfRescueDays,
                dailyCareCost
        );

        this.conservationClassification =
                conservationClassification;

        this.securityCost = securityCost;

        this.specialistTeamRequired =
                specialistTeamRequired;
    }

    public String getConservationClassification() {
        return conservationClassification;
    }

    public double getSecurityCost() {
        return securityCost;
    }

    public boolean isSpecialistTeamRequired() {
        return specialistTeamRequired;
    }

    @Override
    public double calculateTotalRescueCost() {

        double total = calculateBasicRescueCost();

        total += securityCost;

        if (specialistTeamRequired) {
            total += 8000;
        }

        return total;
    }

    @Override
    public String determineRescuePriority() {

        if (specialistTeamRequired) {
            return "Critical";
        }

        return "High";
    }

    @Override
    public String getRescueType() {
        return "Endangered Species Rescue";
    }

    @Override
    public String displaySpecificInformation() {

        String information = "";

        information += "Conservation Classification: "
                + conservationClassification + "\n";

        information += String.format(
                "Security Cost: R%.2f%n",
                securityCost);

        information += "Specialist Team Required: "
                + (specialistTeamRequired ? "Yes" : "No") + "\n";

        return information;
    }
}