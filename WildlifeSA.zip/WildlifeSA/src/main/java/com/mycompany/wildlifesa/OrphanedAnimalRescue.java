/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wildlifesa;

/**
 *
 * @author tshegofatso thamane (ST10515734)
 */



public class OrphanedAnimalRescue extends RescueCase {

    private int estimatedAgeMonths;
    private double feedingCost;
    private boolean fosterCareRequired;

    public OrphanedAnimalRescue(
            String rescueCaseId,
            String animalName,
            String species,
            String rescueLocation,
            String assignedRanger,
            int numberOfRescueDays,
            double dailyCareCost,
            int estimatedAgeMonths,
            double feedingCost,
            boolean fosterCareRequired) {

        super(
                rescueCaseId,
                animalName,
                species,
                rescueLocation,
                assignedRanger,
                numberOfRescueDays,
                dailyCareCost
        );

        this.estimatedAgeMonths = estimatedAgeMonths;
        this.feedingCost = feedingCost;
        this.fosterCareRequired = fosterCareRequired;
    }

    public int getEstimatedAgeMonths() {
        return estimatedAgeMonths;
    }

    public double getFeedingCost() {
        return feedingCost;
    }

    public boolean isFosterCareRequired() {
        return fosterCareRequired;
    }

    @Override
    public double calculateTotalRescueCost() {

        double total = calculateBasicRescueCost();

        total += feedingCost;

        if (fosterCareRequired) {
            total += 2500;
        }

        return total;
    }

    @Override
    public String determineRescuePriority() {

        if (fosterCareRequired) {
            return "High";
        }

        return "Medium";
    }

    @Override
    public String getRescueType() {
        return "Orphaned Animal Rescue";
    }

    @Override
    public String displaySpecificInformation() {

        String information = "";

        information += "Estimated Age: "
                + estimatedAgeMonths + " months\n";

        information += String.format(
                "Feeding Cost: R%.2f%n",
                feedingCost);

        information += "Foster Care Required: "
                + (fosterCareRequired ? "Yes" : "No") + "\n";

        return information;
    }
}