/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wildlifesa;

/**
 *
 * @author tshegofatso thamane (ST10515734)
 */


import java.util.Scanner;

public class Main {

    private static Scanner scanner = new Scanner(System.in);
    private static RescueManager manager = new RescueManager();

    public static void main(String[] args) {

        int choice;

        do {

            displayMenu();

            choice = getIntInput("Enter your choice: ");

            switch (choice) {

                case 1:
                    createRescueCase();
                    break;

                case 2:
                    searchRescueCase();
                    break;

                case 3:
                    startRescue();
                    break;

                case 4:
                    completeRescue();
                    break;

                case 5:
                    generateSummary();
                    break;

                case 6:
                    manager.displayAllRescueCases();
                    break;

                case 7:
                    manager.generateRescueReport();
                    break;

                case 8:
                    System.out.println("\nThank you for using Wildlife SA.");
                    break;

                default:
                    System.out.println("\nInvalid menu choice.");
            }

        } while (choice != 8);

        scanner.close();
    }

    private static void displayMenu() {

        System.out.println("\n========== WILDLIFE RESCUE OPERATIONS SYSTEM ==========");
        System.out.println("1. Create New Rescue Case");
        System.out.println("2. Search Rescue Case");
        System.out.println("3. Start Rescue Operation");
        System.out.println("4. Complete Rescue Operation");
        System.out.println("5. Generate Rescue Summary");
        System.out.println("6. Display All Rescue Cases");
        System.out.println("7. Generate Rescue Report");
        System.out.println("8. Exit");
        System.out.println("=================================");
    }

    private static void createRescueCase() {

        System.out.println("\n========== CREATE RESCUE CASE ==========");

        String rescueCaseId = getNonEmptyString(
                "Enter Rescue Case ID: ");

        if (manager.searchRescueCase(rescueCaseId) != null) {
            System.out.println("A rescue case with this ID already exists.");
            return;
        }

        String animalName = getNonEmptyString(
                "Enter Animal Name: ");

        String species = getNonEmptyString(
                "Enter Species: ");

        String rescueLocation = getNonEmptyString(
                "Enter Rescue Location: ");

        String assignedRanger = getNonEmptyString(
                "Enter Assigned Ranger: ");

        int numberOfRescueDays = getPositiveInt(
                "Enter Number of Rescue Days: ");

        double dailyCareCost = getPositiveDouble(
                "Enter Daily Care Cost: ");

        System.out.println("\nSelect Rescue Case Type:");
        System.out.println("1. Injured Animal Rescue");
        System.out.println("2. Orphaned Animal Rescue");
        System.out.println("3. Endangered Species Rescue");

        int type = getIntInput("Enter type: ");

        RescueCase rescueCase = null;

        switch (type) {

            case 1:

                String injuryDescription = getNonEmptyString(
                        "Enter Injury Description: ");

                double veterinaryTreatmentCost = getPositiveDouble(
                        "Enter Veterinary Treatment Cost: ");

                boolean surgeryRequired = getYesNo(
                        "Is Surgery Required? (Y/N): ");

                rescueCase = new InjuredAnimalRescue(
                        rescueCaseId,
                        animalName,
                        species,
                        rescueLocation,
                        assignedRanger,
                        numberOfRescueDays,
                        dailyCareCost,
                        injuryDescription,
                        veterinaryTreatmentCost,
                        surgeryRequired
                );

                break;

            case 2:

                int estimatedAgeMonths = getPositiveInt(
                        "Enter Estimated Age in Months: ");

                double feedingCost = getPositiveDouble(
                        "Enter Feeding Cost: ");

                boolean fosterCareRequired = getYesNo(
                        "Is Foster Care Required? (Y/N): ");

                rescueCase = new OrphanedAnimalRescue(
                        rescueCaseId,
                        animalName,
                        species,
                        rescueLocation,
                        assignedRanger,
                        numberOfRescueDays,
                        dailyCareCost,
                        estimatedAgeMonths,
                        feedingCost,
                        fosterCareRequired
                );

                break;

            case 3:

                String conservationClassification = getNonEmptyString(
                        "Enter Conservation Classification: ");

                double securityCost = getPositiveDouble(
                        "Enter Security Cost: ");

                boolean specialistTeamRequired = getYesNo(
                        "Is Specialist Team Required? (Y/N): ");

                rescueCase = new EndangeredSpeciesRescue(
                        rescueCaseId,
                        animalName,
                        species,
                        rescueLocation,
                        assignedRanger,
                        numberOfRescueDays,
                        dailyCareCost,
                        conservationClassification,
                        securityCost,
                        specialistTeamRequired
                );

                break;

            default:

                System.out.println("Invalid rescue type.");
                return;
        }

        if (manager.addRescueCase(rescueCase)) {

            System.out.println("\nRescue case created successfully.");

        } else {

            System.out.println("\nFailed to create rescue case.");
        }
    }

    private static void searchRescueCase() {

        System.out.println("\n========== SEARCH RESCUE CASE ==========");

        String rescueCaseId = getNonEmptyString(
                "Enter Rescue Case ID: ");

        RescueCase rescueCase =
                manager.searchRescueCase(rescueCaseId);

        if (rescueCase == null) {

            System.out.println("Rescue case not found.");

        } else {

            System.out.println("\nRescue case found.");
            System.out.println(rescueCase.generateRescueSummary());
        }
    }

    private static void startRescue() {

        System.out.println("\n========== START RESCUE ==========");

        String rescueCaseId = getNonEmptyString(
                "Enter Rescue Case ID: ");

        if (manager.startRescueOperation(rescueCaseId)) {

            System.out.println(
                    "Rescue operation started successfully.");

        } else {

            System.out.println(
                    "Rescue case not found.");
        }
    }

    private static void completeRescue() {

        System.out.println("\n========== COMPLETE RESCUE ==========");

        String rescueCaseId = getNonEmptyString(
                "Enter Rescue Case ID: ");

        if (manager.completeRescueOperation(rescueCaseId)) {

            System.out.println(
                    "Rescue operation completed successfully.");

        } else {

            System.out.println(
                    "Rescue case not found.");
        }
    }

    private static void generateSummary() {

        System.out.println("\n========== GENERATE SUMMARY ==========");

        String rescueCaseId = getNonEmptyString(
                "Enter Rescue Case ID: ");

        String summary =
                manager.generateRescueSummary(rescueCaseId);

        if (summary == null) {

            System.out.println("Rescue case not found.");

        } else {

            System.out.println(summary);
        }
    }

    private static String getNonEmptyString(String message) {

        while (true) {

            System.out.print(message);

            String input = scanner.nextLine().trim();

            if (!input.isEmpty()) {
                return input;
            }

            System.out.println(
                    "Input cannot be blank. Please try again.");
        }
    }

    private static int getIntInput(String message) {

        while (true) {

            System.out.print(message);

            try {

                return Integer.parseInt(
                        scanner.nextLine().trim());

            } catch (NumberFormatException e) {

                System.out.println(
                        "Please enter a valid number.");
            }
        }
    }

    private static int getPositiveInt(String message) {

        while (true) {

            int value = getIntInput(message);

            if (value > 0) {
                return value;
            }

            System.out.println(
                    "Value must be greater than 0.");
        }
    }

    private static double getPositiveDouble(String message) {

        while (true) {

            System.out.print(message);

            try {

                double value = Double.parseDouble(
                        scanner.nextLine().trim());

                if (value > 0) {
                    return value;
                }

                System.out.println(
                        "Value must be greater than 0.");

            } catch (NumberFormatException e) {

                System.out.println(
                        "Please enter a valid number.");
            }
        }
    }

    private static boolean getYesNo(String message) {

        while (true) {

            System.out.print(message);

            String input =
                    scanner.nextLine().trim().toUpperCase();

            if (input.equals("Y")) {
                return true;
            }

            if (input.equals("N")) {
                return false;
            }

            System.out.println(
                    "Please enter Y or N.");
        }
    }
}