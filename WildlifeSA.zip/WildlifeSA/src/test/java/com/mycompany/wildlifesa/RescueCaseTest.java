/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wildlifesa;

/**
 *
 * @author tshegofatso thamane (ST10515734)
 */


import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RescueCaseTest {

    // Test 1: Injured Animal Rescue cost
    @Test
    public void testInjuredAnimalRescueCost() {

        InjuredAnimalRescue rescue =
                new InjuredAnimalRescue(
                        "I001",
                        "Leo",
                        "Lion",
                        "Kruger National Park",
                        "Ranger John",
                        5,
                        1000.00,
                        "Broken leg",
                        3000.00,
                        true
                );

        double expectedCost =
                (5 * 1000.00) + 3000.00 + 5000.00;

        assertEquals(
                expectedCost,
                rescue.calculateTotalRescueCost(),
                0.01
        );
    }

    // Test 2: Orphaned Animal Rescue cost
    @Test
    public void testOrphanedAnimalRescueCost() {

        OrphanedAnimalRescue rescue =
                new OrphanedAnimalRescue(
                        "O001",
                        "Simba",
                        "Lion",
                        "Limpopo",
                        "Ranger Peter",
                        4,
                        500.00,
                        6,
                        1500.00,
                        true
                );

        double expectedCost =
                (4 * 500.00) + 1500.00 + 2500.00;

        assertEquals(
                expectedCost,
                rescue.calculateTotalRescueCost(),
                0.01
        );
    }

    // Test 3: Endangered Species Rescue cost
    @Test
    public void testEndangeredSpeciesRescueCost() {

        EndangeredSpeciesRescue rescue =
                new EndangeredSpeciesRescue(
                        "E001",
                        "Rhino",
                        "Black Rhino",
                        "KwaZulu-Natal",
                        "Ranger James",
                        3,
                        2000.00,
                        "Critically Endangered",
                        4000.00,
                        true
                );

        double expectedCost =
                (3 * 2000.00) + 4000.00 + 8000.00;

        assertEquals(
                expectedCost,
                rescue.calculateTotalRescueCost(),
                0.01
        );
    }

    // Test 4: Rescue priority
    @Test
    public void testRescuePriority() {

        InjuredAnimalRescue rescue =
                new InjuredAnimalRescue(
                        "I002",
                        "Max",
                        "Leopard",
                        "Mpumalanga",
                        "Ranger David",
                        2,
                        500.00,
                        "Serious injury",
                        2000.00,
                        true
                );

        assertEquals(
                "High",
                rescue.determineRescuePriority()
        );
    }

    // Test 5: Rescue status updates
    @Test
    public void testRescueStatusUpdates() {

        InjuredAnimalRescue rescue =
                new InjuredAnimalRescue(
                        "I003",
                        "Rocky",
                        "Elephant",
                        "Limpopo",
                        "Ranger Mike",
                        5,
                        1000.00,
                        "Leg injury",
                        1500.00,
                        false
                );

        assertEquals(
                "Awaiting Rescue",
                rescue.getCurrentRescueStatus()
        );

        rescue.startRescue();

        assertEquals(
                "Rescue In Progress",
                rescue.getCurrentRescueStatus()
        );

        rescue.completeRescue();

        assertEquals(
                "Completed",
                rescue.getCurrentRescueStatus()
        );
    }

    // Test 6: Search for an existing rescue case
    @Test
    public void testSearchForRescueCase() {

        RescueManager manager = new RescueManager();

        InjuredAnimalRescue rescue =
                new InjuredAnimalRescue(
                        "I004",
                        "Bella",
                        "Lion",
                        "Free State",
                        "Ranger Tom",
                        3,
                        800.00,
                        "Injury",
                        1000.00,
                        false
                );

        manager.addRescueCase(rescue);

        RescueCase found =
                manager.searchRescueCase("I004");

        assertNotNull(found);

        assertEquals(
                "I004",
                found.getRescueCaseId()
        );
    }

    // Test 7: Searching for a case that does not exist
    @Test
    public void testSearchForNonExistingRescueCase() {

        RescueManager manager = new RescueManager();

        RescueCase found =
                manager.searchRescueCase("DOESNOTEXIST");

        assertNull(found);
    }

    // Test 8: Prevent duplicate Rescue Case IDs
    @Test
    public void testDuplicateRescueCaseId() {

        RescueManager manager = new RescueManager();

        InjuredAnimalRescue firstRescue =
                new InjuredAnimalRescue(
                        "D001",
                        "Lion One",
                        "Lion",
                        "Limpopo",
                        "Ranger One",
                        3,
                        500.00,
                        "Leg injury",
                        1000.00,
                        false
                );

        InjuredAnimalRescue secondRescue =
                new InjuredAnimalRescue(
                        "D001",
                        "Lion Two",
                        "Lion",
                        "Limpopo",
                        "Ranger Two",
                        4,
                        600.00,
                        "Head injury",
                        2000.00,
                        true
                );

        assertTrue(
                manager.addRescueCase(firstRescue)
        );

        assertFalse(
                manager.addRescueCase(secondRescue)
        );

        assertEquals(
                1,
                manager.getNumberOfRescueCases()
        );
    }
}